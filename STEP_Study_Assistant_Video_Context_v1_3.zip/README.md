# STEP Quiz Study Assistant
Manifest V3 Chrome/Edge extension for `https://english.steptest.in/learn/*` and `/test*`.

**Mandatory branding:** `Created By - Dinezz`

## Features
- Debounced MutationObserver for dynamic question changes.
- Heuristic detection of lettered MCQ options, question/context, possible word-bank chips, and fill inputs.
- Draggable floating panel, confidence estimate, uncertainty state, refresh/collapse/hide.
- Green outline/checkmark on a suggested MCQ option or matching word-bank chip. For multiple blanks, AI must return one ordered word per detected blank; the panel displays `Blank 1: ...`, `Blank 2: ...` and flags incomplete results.
- Optional Gemini API analysis, 14-second timeout, model fallback, and local fallback.
- Optional visible YouTube captions from the embedded video are passed as extra context when the player renders captions. Captions must be enabled/available; this extension does not record audio or transcribe silent video.
- Local cache and popup settings.
- Does not select answers, submit the quiz, or click Next.

## Install
1. Extract this ZIP.
2. Open `chrome://extensions` (Chrome) or `edge://extensions` (Edge).
3. Enable Developer mode → **Load unpacked** → select the extracted folder containing `manifest.json`.
4. Open a STEP lesson page and refresh it.

## Gemini API setup
1. Create a key at https://aistudio.google.com/apikey.
2. Paste it into the extension popup, choose a model, and click **Save API settings**.
3. Refresh the STEP lesson page. Key is stored in `chrome.storage.local`; it is not hardcoded or logged. It is sent to Google only for analysis. Never share the key.

Model availability and free quotas can change. If 404 appears, select another model; 429/503 may mean quota or temporary demand.

## Flow
1. Observe DOM changes; debounce ~180ms.
2. Extract a page snapshot and compute a fingerprint.
3. Reuse cache if enabled.
4. Run local context heuristics; optionally ask Gemini for JSON.
5. Validate the AI's MCQ answer against actual options. If AI fails, show local result and error.
6. Show answer, confidence, reason, and highlights without blocking quiz controls.

## Video context limitations\nThe YouTube helper reads only caption text rendered in the embedded player. To avoid wasting API quota, after playing the video with captions enabled, click the panel's ↻ Refresh button to analyze the captured caption context. If captions are disabled, unavailable, or the video is not YouTube, the extension cannot infer spoken content directly; it will use the visible question/options and may be less accurate. Gemini quota errors (429/503) cannot be bypassed by the extension; switching models may help only if another model has available quota.\n\n## Permissions
- `storage`: preferences, optional API key, cache.
- `activeTab`: popup manual analyze action.
- Host permissions restricted to STEP and Gemini API.

## Limitations
This is a DOM heuristic, not an official STEP integration. Audio/video-only context, shadow DOM, embedded frames, unusual custom controls, and some word-bank layouts may not be readable. Local mode is deliberately conservative and weaker than AI. AI can also be wrong; confidence is an estimate, not verified probability. No 100% accuracy guarantee.
