(() => {
  if (window.__stepCaptionReaderLoaded) return;
  window.__stepCaptionReaderLoaded = true;
  const pick = () => [...document.querySelectorAll(".ytp-caption-segment,[class*='caption-window'] [class*='caption-segment']")]
    .map(n => (n.innerText || n.textContent || "").trim()).filter(Boolean).join(" ").replace(/\s+/g," ").slice(0,1200);
  let last = "", timer;
  const publish = () => {
    const text = pick();
    if (!text || text === last) return;
    last = text;
    chrome.runtime.sendMessage({type:"STEP_VIDEO_CAPTION",text,url:location.href,at:Date.now()},()=>void chrome.runtime.lastError);
  };
  const obs = new MutationObserver(() => { clearTimeout(timer); timer=setTimeout(publish,120); });
  const start = () => { if(document.documentElement) obs.observe(document.documentElement,{subtree:true,childList:true,characterData:true}); publish(); };
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",start,{once:true}); else start();
  setInterval(publish,1200);
})();