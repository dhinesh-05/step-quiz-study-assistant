const D={enabled:true,panelVisible:true,cacheEnabled:true,useGemini:true,geminiModel:"gemini-2.5-flash-lite",apiKey:""};
const videoContextByTab = new Map();
chrome.runtime.onInstalled.addListener(async()=>{const x=await chrome.storage.local.get(Object.keys(D)),m={};for(const[k,v]of Object.entries(D))if(x[k]===undefined)m[k]=v;if(Object.keys(m).length)await chrome.storage.local.set(m)});
chrome.runtime.onMessage.addListener((m,s,reply)=>{
 if(m?.type==="STEP_GET_PREFS"){chrome.storage.local.get(Object.keys(D)).then(p=>reply({ok:true,prefs:{...D,...p}}));return true}
 if(m?.type==="STEP_GEMINI_ANALYZE"){gemini(m.payload).then(reply);return true}
 if(m?.type==="STEP_VIDEO_CAPTION"){
   const tabId=s?.tab?.id;
   if(Number.isInteger(tabId) && typeof m.text==="string" && m.text.trim()){
     const prev=videoContextByTab.get(tabId)||{};
     const text=m.text.trim().slice(0,1200);
     videoContextByTab.set(tabId,{text:(prev.text&&prev.text!==text ? (prev.text+" "+text) : text).slice(-4000),updatedAt:Date.now(),url:m.url||""});
     chrome.tabs.sendMessage(tabId,{type:"STEP_VIDEO_CONTEXT_UPDATED"}).catch(()=>{});
   }
   reply({ok:true});return;
 }
 if(m?.type==="STEP_GET_VIDEO_CONTEXT"){
   const tabId=s?.tab?.id, v=Number.isInteger(tabId)?videoContextByTab.get(tabId):null;
   reply({ok:true,videoContext:v && Date.now()-v.updatedAt<120000 ? v.text : ""});return;
 }
});
async function gemini(p){
 const pref={...D,...await chrome.storage.local.get(Object.keys(D))};if(!pref.apiKey)return{ok:false,error:"Add a Gemini API key in the popup."};
 const models=[...new Set([pref.geminiModel,"gemini-2.5-flash-lite","gemini-2.5-flash","gemini-2.0-flash-lite"])];
 const prompt=`You are a careful English vocabulary and grammar tutor. Solve the activity using the passage and the available word bank.
Return ONLY valid JSON using this schema:
{"answer":"for MCQ use the exact option ID; for one blank use one exact word; for multiple blanks use an array such as [\\"bruise\\",\\"emergency\\",\\"prescription\\"].","reason":"brief context-based reason","confidence":0.0}
IMPORTANT:
- If blankCount is 3, answer MUST contain exactly 3 strings in reading order (left-to-right, then top-to-bottom).
- If blankCount is 2, answer MUST contain exactly 2 strings.
- Never return an empty string or an empty array when a solvable question is provided.
- Use words from the word bank; do not return the word bank itself.
- Do not collapse multiple blanks into one answer. Preserve the order of blanks.
- If the number of blanks cannot be determined, still return the most likely ordered answers and set confidence low.
- For MCQ only, answer must be exactly one supplied option ID.
Type: ${p.kind}
Page title: ${p.title||""}
Question/instruction: ${p.question||""}
Passage/dialogue with context:
${(p.passage||"").slice(0,4200)}
Visible video captions (only if captions are enabled and rendered in the embedded player):
${(p.videoContext||"").slice(-3500) || "(no visible captions detected; do not assume what the video said)"}
Blank location context:
${(p.blankContexts||[]).join("\\n").slice(0,1500)}
Options:
${(p.options||[]).map(o=>o.id+". "+o.text).join("\\n")||"(none detected)"}
Word bank (available choices):
${(p.wordBank||[]).join(", ")||"(none detected)"}
Number of blanks detected: ${p.blankCount||0}`;
 let last="Gemini request failed.";
 for(const model of models){const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),14000);try{
  const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(pref.apiKey)}`,{method:"POST",signal:ctl.signal,headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{temperature:0.1,maxOutputTokens:220,responseMimeType:"application/json"}})});
  const d=await r.json().catch(()=>({}));if(!r.ok){last=d?.error?.message||`HTTP ${r.status}`;if([400,404,429,500,503].includes(r.status))continue;return{ok:false,error:last}}
  const raw=d?.candidates?.[0]?.content?.parts?.map(x=>x.text||"").join("").trim();if(!raw)return{ok:false,error:"Gemini returned no answer."};
  let a;try{a=JSON.parse(raw.replace(/^```json\s*|\s*```$/g,""))}catch{return{ok:false,error:"Could not parse Gemini response."}}
  let answer=(a.answer!==undefined?a.answer:(a.answers!==undefined?a.answers:a.blankAnswers));if(p.options?.length){const id=String(answer).trim().toUpperCase().replace(/[.)]$/,"");const o=p.options.find(x=>x.id.toUpperCase()===id||x.text.toLowerCase()===String(answer).trim().toLowerCase());if(!o)return{ok:false,error:"AI answer did not match an option."};return{ok:true,answer:{answer:o.id,answerText:o.text,reason:String(a.reason||""),confidence:Math.max(0,Math.min(1,Number(a.confidence)||0)),kind:"mcq",source:"AI · "+model}}}
  if(Array.isArray(answer))answer=answer.map(x=>String(x).trim()).filter(Boolean);else answer=String(answer??"").trim();
  if((Array.isArray(answer)&&!answer.length)||(!Array.isArray(answer)&&!answer))return{ok:false,error:"Gemini returned an empty answer."};
  if(p.kind==="wordbank"&&Number(p.blankCount)>1){
    if(!Array.isArray(answer))return{ok:false,error:`Gemini returned one answer for ${p.blankCount} blanks.`};
    if(answer.length!==Number(p.blankCount))return{ok:false,error:`Gemini returned ${answer.length} answers for ${p.blankCount} blanks.`};
    const bank=(p.wordBank||[]).map(w=>w.toLowerCase());
    if(bank.length && answer.some(w=>!bank.includes(String(w).toLowerCase())))return{ok:false,error:"One or more answers were not in the detected word bank."};
  }
  return{ok:true,answer:{answer,answerText:Array.isArray(answer)?answer.join(" · "):answer,reason:String(a.reason||""),confidence:Math.max(0,Math.min(1,Number(a.confidence)||0)),kind:p.kind,source:"AI · "+model}}
  }catch(e){last=e.name==="AbortError"?"Gemini timed out after 14 seconds.":e.message||"Network error.";return{ok:false,error:last}}finally{clearTimeout(timer)}}return{ok:false,error:last}
}