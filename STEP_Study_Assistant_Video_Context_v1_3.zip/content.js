(()=>{
if(window.__stepStudyLoaded)return;window.__stepStudyLoaded=true;
const BRAND="Created By - Dinezz",PREFIX="step-answer-v2:";
const S={enabled:true,panelVisible:true,cacheEnabled:true,useGemini:true,last:"",timer:null,collapsed:false};
let panel,body,status,drag=null;
const send=m=>new Promise(resolve=>chrome.runtime.sendMessage(m,r=>resolve(r||{ok:false,error:chrome.runtime.lastError?.message||"Extension message failed"})));
const vis=e=>{if(!e||!e.isConnected)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"&&Number(s.opacity)!==0};
const clean=s=>(s||"").replace(/\s+/g," ").replace(/^(SELECTED ANSWER|CORRECT ANSWER|SELECTED|CORRECT)\s*[:\-]?\s*/i,"").trim();
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return(h>>>0).toString(16)}
function makePanel(){
 if(document.getElementById("step-study-panel")){panel=document.getElementById("step-study-panel");body=panel.querySelector(".step-body");status=panel.querySelector(".step-status");return}
 panel=document.createElement("section");panel.id="step-study-panel";
 panel.innerHTML=`<header class="step-head"><b>STEP <i>•</i> STUDY ASSISTANT</b><div><button data-a="refresh" title="Analyze">↻</button><button data-a="collapse" title="Collapse">−</button><button data-a="hide" title="Hide">×</button></div></header><div class="step-body"><div class="step-status">Ready to analyze.</div><div class="step-answer"></div><div class="step-reason"></div></div><footer class="step-footer">${BRAND}</footer>`;
 document.documentElement.appendChild(panel);body=panel.querySelector(".step-body");status=panel.querySelector(".step-status");
 panel.addEventListener("click",async e=>{const b=e.target.closest("button[data-a]");if(!b)return;if(b.dataset.a==="refresh")analyze(true);if(b.dataset.a==="collapse"){S.collapsed=!S.collapsed;body.hidden=S.collapsed;panel.querySelector("footer").hidden=S.collapsed;b.textContent=S.collapsed?"+":"−"}if(b.dataset.a==="hide"){S.panelVisible=false;panel.hidden=true;await chrome.storage.local.set({panelVisible:false})}});
 const h=panel.querySelector(".step-head");h.addEventListener("pointerdown",e=>{if(e.target.closest("button"))return;const r=panel.getBoundingClientRect();drag={x:e.clientX,y:e.clientY,l:r.left,t:r.top};h.setPointerCapture(e.pointerId)});h.addEventListener("pointermove",e=>{if(!drag)return;panel.style.left=Math.max(0,Math.min(innerWidth-240,drag.l+e.clientX-drag.x))+"px";panel.style.top=Math.max(0,Math.min(innerHeight-90,drag.t+e.clientY-drag.y))+"px";panel.style.right="auto"});h.addEventListener("pointerup",()=>drag=null)
}
function stat(t,load=false){status.innerHTML=load?'<span class="step-spinner"></span>'+esc(t):esc(t)}
function show(r){const a=panel.querySelector(".step-answer");a.className="step-answer"+(r.uncertain?" step-uncertain":"");a.innerHTML=`<div class="step-answer-line">${esc(r.label||"Suggested answer")}</div><div class="step-answer-text">${esc(r.text||"Not enough information.")}</div><div class="step-meta"><span>${esc(r.source||"Local")}</span><span>${Math.round((r.confidence||0)*100)}% confidence</span></div>`;panel.querySelector(".step-reason").textContent=r.reason||""}
function clearHi(){document.querySelectorAll(".step-recommended").forEach(e=>e.classList.remove("step-recommended"))}
function extract(){
 const leaves=[...document.querySelectorAll("body *")].filter(e=>vis(e)&&!e.closest("#step-study-panel")&&e.children.length===0).map(el=>({el,text:clean(el.innerText||el.textContent||"")})).filter(x=>x.text&&x.text.length<900);
 const map=new Map();for(const x of leaves){const m=x.text.match(/^([A-D]|[1-9])\s*[.)]\s+(.+)$/s);if(m&&m[2].length<350&&!map.has(m[1].toUpperCase()))map.set(m[1].toUpperCase(),{id:m[1].toUpperCase(),text:clean(m[2]),el:x.el})}
 const options=[...map.values()].sort((a,b)=>a.id.localeCompare(b.id,undefined,{numeric:true}));
 const junk=/^(submit|next|previous|continue|skip|help|close|watch on youtube)$/i;
 const candidates=leaves.filter(x=>x.text.length>=7&&!junk.test(x.text)&&!options.some(o=>o.el===x.el));
 const headingEls=[...document.querySelectorAll("h1,h2,h3,[role=heading],main p,[role=main] p")].filter(vis).map(el=>({el,text:clean(el.innerText||el.textContent||"")})).filter(x=>x.text.length>=12&&x.text.length<500);
 const q=headingEls.find(x=>/[?]|what question|which answer|choose|fill in|complete the|speak and express/i.test(x.text))
   || candidates.filter(x=>(/[?]$|fill in|choose|select|complete the|what does|which|listen|speak|express|meaning|best response|blank/i).test(x.text)).sort((a,b)=>a.text.length-b.text.length)[0]
   || candidates.filter(x=>x.text.length<260).sort((a,b)=>b.text.length-a.text.length)[0];
 const inputs=[...document.querySelectorAll('input:not([type="hidden"]):not([type="button"]),textarea,[contenteditable="true"]')].filter(vis);
 const dropCandidates=[...document.querySelectorAll('[class*="drop"],[class*="blank"],[class*="slot"],[data-drop],input[placeholder*="_"],input[aria-label*="blank"]')].filter(vis);
 const drop=dropCandidates.filter(el=>{
   const r=el.getBoundingClientRect(), cs=getComputedStyle(el), txt=clean(el.innerText||el.textContent||el.value||"");
   const looksLikeSlot=cs.borderStyle==="dashed" || /drop|blank|slot/i.test(String(el.className||"")) || el.hasAttribute("data-drop");
   return r.width>=24 && r.height>=12 && (looksLikeSlot || !txt || el.matches("input,textarea,[contenteditable=true]"));
 });
 const chips=leaves.filter(x=>!options.some(o=>o.el===x.el)&&x.text.length>1&&x.text.length<40&&!junk.test(x.text)&&(x.el.matches("button,[role=button]")||/chip|word|bank|drag/i.test(String(x.el.className||"")))).slice(0,20);
 const unique=[...new Map(chips.map(c=>[c.text.toLowerCase(),c])).values()];
 let kind="unknown";if(options.length>=2)kind="mcq";else if(unique.length>=3)kind="wordbank";else if(inputs.length)kind="fill";else if(/true\s*\/?\s*false/i.test(q?.text||""))kind="truefalse";else if(/speak and express/i.test(document.title+" "+(q?.text||"")))kind="speak";
 const main=document.querySelector("main,[role=main]")||document.body;
 let passage=clean((main.innerText||"").split("\n").map(s=>s.trim()).filter(s=>s&&!junk.test(s)&&!/^STEP\s*[•-]/i.test(s)).join("\n")).replace(/Created By - Dinezz/g,"").slice(0,4500);
 const visibleSlots=drop.filter(el=>!drop.some(other=>other!==el && other.contains(el) && /drop|blank|slot/i.test(String(other.className||""))));
 const underscoreCount=(passage.match(/_{2,}/g)||[]).length;
 const blankCount=Math.max(visibleSlots.length,underscoreCount,inputs.length && !options.length ? inputs.length : 0);
 const blankContexts=visibleSlots.slice(0,12).map((el,i)=>{
   let node=el.parentElement;
   for(let depth=0;node&&depth<4;depth++,node=node.parentElement){
     const t=clean(node.innerText||node.textContent||"");
     if(t.length>=18&&t.length<=650)return `Blank ${i+1} nearby text: ${t}`;
   }
   return `Blank ${i+1}: location detected in activity passage`;
 });
 const data={title:document.title,kind,question:q?.text||"",passage,blankContexts,options:options.map(({id,text})=>({id,text})),wordBank:unique.map(x=>x.text),blankCount};
 data.fingerprintText=`${data.title}\n${kind}\n${data.question}\n${data.options.map(o=>o.id+":"+o.text).join("\n")}\n${data.wordBank.join("|")}\n${passage.slice(0,450)}`;
 data.optionElements=options;data.chipElements=unique;return data
}
function local(p){
 const q=(p.question+" "+p.passage).toLowerCase(),opts=p.options||[];
 if(opts.length>=2){const patterns=[[/doctor|hospital|clinic|appointment|symptom/,/appointment|doctor|medical|symptom|prescription|medicine|patient|clinic/],[/knees?|joint|pain|ache/,/ache|pain|joint|knee|hurt|injury/],[/bruise|fall|injur/,/bruise|injury|hurt|swollen|pain/],[/product|design|improve|feedback/,/improve|suggest|feedback|constructive|design/],[/tell you something|share.*thought|opinion|think/,/tell you|share|thought|opinion|think|elaborate/],[/apolog|sorry|mistake/,/sorry|apolog|regret|mistake/],[/thank/,/welcome|pleasure|thank/],[/request|could you|would you mind/,/please|certainly|sure|of course|happy to/],[/flight|check[ -]?in|boarding|airport/,/how many hours|when .*check.?in|what time|before the flight/]];
 let best=null,bs=0,second=0;for(const o of opts){let score=0;for(const [qr,or] of patterns)if(qr.test(q)&&or.test(o.text.toLowerCase()))score++;if(score>bs){second=bs;bs=score;best=o}else if(score>second)second=score}
 if(best&&bs){const confidence=Math.min(.78,.48+bs*.09+(bs>second?.06:0));return{answer:best.id,answerText:best.text,reason:"Local grammar/context clues suggest this option; verify against the activity.",confidence,kind:"mcq",source:"Local",uncertain:confidence<.65}}
 return{answer:"",answerText:"Not enough context for a reliable recommendation.",reason:"Local mode avoids guessing. Add a Gemini API key for deeper context analysis.",confidence:.2,kind:"mcq",source:"Local",uncertain:true}}
 if(p.kind==="wordbank")return{answer:"",answerText:p.blankCount>1?`Detected ${p.blankCount} blanks. Enable Gemini to map each blank in order.`:"Word bank detected; AI is needed to match the blank reliably.",reason:"Local mode will not guess a word-bank mapping when context is insufficient.",confidence:.2,source:"Local",uncertain:true};
 return{answer:"",answerText:"Question format not confidently recognized.",reason:"Try Refresh or enable Gemini AI.",confidence:.1,source:"Local",uncertain:true}
}
async function analyze(force=false){
 if(!S.enabled)return;makePanel();if(!S.panelVisible)return;const p=extract();
 const vc=await send({type:"STEP_GET_VIDEO_CONTEXT"});
 p.videoContext=vc?.videoContext||"";
 const key=hash(p.fingerprintText+"\\nVIDEO:"+p.videoContext.slice(-600));if(!force&&key===S.last)return;S.last=key;clearHi();stat(p.videoContext?"Question + video captions · analyzing…":"Question detected · analyzing…",true);panel.querySelector(".step-answer").innerHTML="";panel.querySelector(".step-reason").textContent="";
 const ck=PREFIX+key;if(S.cacheEnabled){const c=await chrome.storage.local.get(ck);if(c[ck]){render(c[ck],p);return}}
 const localResult=local(p);
 if(S.useGemini){const payload={title:p.title,kind:p.kind,question:p.question,passage:p.passage,videoContext:p.videoContext||"",blankContexts:p.blankContexts||[],options:p.options,wordBank:p.wordBank,blankCount:p.blankCount};const ai=await send({type:"STEP_GEMINI_ANALYZE",payload});if(ai?.ok&&ai.answer){const r={...ai.answer,source:ai.answer.source||"AI",uncertain:ai.answer.confidence<.62};render(r,p);if(S.cacheEnabled)await chrome.storage.local.set({[ck]:r});return}localResult.reason+=(ai?.error?" AI unavailable: "+ai.error:"")}
 render(localResult,p);if(S.cacheEnabled)await chrome.storage.local.set({[ck]:localResult})
}
function render(r,p){
 stat(`${p.kind.toUpperCase()} · ${r.source||"Local"}`);
 let answerText=r.answerText||r.answer||"Not enough information.";
 let label=r.answer&&r.kind==="mcq"?`Recommended answer: ${r.answer}`:r.answer?"Recommended answer":"Suggestion";
 if(Array.isArray(r.answer)){
   answerText=r.answer.map((word,i)=>`Blank ${i+1}: ${word}`).join("\n");
   label=`Answers for ${r.answer.length} blank${r.answer.length===1?"":"s"}`;
 } else if(r.answer && p.kind==="wordbank" && p.blankCount>1) {
   answerText=`Only one answer was returned, but ${p.blankCount} blanks were detected. Refresh or retry AI analysis.`;
   label="Incomplete blank mapping";
   r.uncertain=true;
 }
 show({label,text:answerText,reason:r.reason,confidence:r.confidence,source:r.source,uncertain:r.uncertain||r.confidence<.62});
 if(r.answer&&p.optionElements?.length&&!Array.isArray(r.answer)){const o=p.optionElements.find(x=>x.id.toUpperCase()===String(r.answer).toUpperCase());if(o?.el)o.el.classList.add("step-recommended")}
 if(r.answer&&p.chipElements?.length){const words=Array.isArray(r.answer)?r.answer:String(r.answer).split(/[,\n;|]+/).map(x=>x.trim());for(const c of p.chipElements)if(words.some(w=>w.toLowerCase()===c.text.toLowerCase()))c.el.classList.add("step-recommended")}
}
async function init(){makePanel();const res=await send({type:"STEP_GET_PREFS"}),p=res.prefs||{};Object.assign(S,{enabled:p.enabled!==false,panelVisible:p.panelVisible!==false,cacheEnabled:p.cacheEnabled!==false,useGemini:p.useGemini!==false});panel.hidden=!S.enabled||!S.panelVisible;
 const ob=new MutationObserver(()=>{clearTimeout(S.timer);S.timer=setTimeout(()=>analyze(),180)});ob.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:["class","aria-selected","disabled","placeholder"]});setTimeout(()=>analyze(),350);
 chrome.storage.onChanged.addListener((changes,area)=>{if(area!=="local")return;for(const k of ["enabled","panelVisible","cacheEnabled","useGemini"])if(changes[k])S[k]=changes[k].newValue!==false;if(panel)panel.hidden=!S.enabled||!S.panelVisible;if(S.enabled&&changes.useGemini)analyze(true)})
}
chrome.runtime.onMessage.addListener((m,s,reply)=>{
 if(m?.type==="STEP_ANALYZE_NOW"){analyze(true);reply({ok:true})}
 if(m?.type==="STEP_VIDEO_CONTEXT_UPDATED"){
   // Do not call Gemini for every caption frame; user can press ↻ after captions appear.
   stat("Video captions detected · click ↻ to analyze with video context");
   reply({ok:true});
 }
});
init();
})();